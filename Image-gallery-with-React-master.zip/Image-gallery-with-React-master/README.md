Galería imágenes con React y CSS (Sass).

Basada en el tutorial de [Alex Devero](https://www.linkedin.com/pulse/learn-react-practice-create-stunning-image-gallery-alex-devero) y refactorizada con las herramientas que ofrece [Create-react-app](https://github.com/facebook/create-react-app)

Se puede ver la revisión de dicha aplicación en el artículo de mi blog donde, además de explicar la aplicación, comento los cambios que he realizado.

[Artículo de mi blog](https://felipefcor.github.io/2019-02-02-Galeria-imagenes-con-React/)
